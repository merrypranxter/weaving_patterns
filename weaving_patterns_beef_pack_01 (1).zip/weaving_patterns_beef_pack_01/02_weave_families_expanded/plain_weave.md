# Plain Weave

## Definition

**Plain Weave** is a woven structure or woven-pattern family based on 1/1 over-under alternation.

## Binary logic

At each intersection, the drawdown decides whether warp or weft is visible. In this family, the decision pattern emphasizes 1/1 over-under alternation.

## Visual signature

Expect checkerlike grid, honest cloth, high stability. The surface should show thread direction, interlacement, and material behavior instead of looking like a flat printed imitation.

## Draft behavior

Document threading, tie-up, treadling, and drawdown as separate systems when possible. For generative use, encode the family as a repeat matrix or procedural cell function.

## Shader / genart translation

Useful controls:

- thread count
- repeat size
- float length
- warp color array
- weft color array
- fiber fuzz
- anisotropic highlight strength
- tension wobble
- shadow depth under floats

## Prompt language

Use: "thread-level plain weave structure, visible warp and weft, over-under interlacement, float shadows, repeat-unit logic, real woven surface".

## Anti-drift

Do not make this a printed graphic laid on cloth. The pattern must be born from threads.
