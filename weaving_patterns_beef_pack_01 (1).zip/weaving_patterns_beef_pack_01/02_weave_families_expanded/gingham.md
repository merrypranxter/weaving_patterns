# Gingham

## Definition

**Gingham** is a woven structure or woven-pattern family based on equal colored warp/weft stripes.

## Binary logic

At each intersection, the drawdown decides whether warp or weft is visible. In this family, the decision pattern emphasizes equal colored warp/weft stripes.

## Visual signature

Expect simple check, intersection color logic. The surface should show thread direction, interlacement, and material behavior instead of looking like a flat printed imitation.

## Draft behavior

Document threading, tie-up, treadling, and drawdown as separate systems when possible. For generative use, encode the family as a repeat matrix or procedural cell function.

## Shader / genart translation

Useful controls:

- thread count
- repeat size
- float length
- warp color array
- weft color array
- fiber fuzz
- anisotropic highlight strength
- tension wobble
- shadow depth under floats

## Prompt language

Use: "thread-level gingham structure, visible warp and weft, over-under interlacement, float shadows, repeat-unit logic, real woven surface".

## Anti-drift

Do not make this a printed graphic laid on cloth. The pattern must be born from threads.
